package examen;
import java.util.*;

public class examen1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner in = new Scanner (System.in);

		System.out.print("Introudeix un enter (fila): ");
		int n = in.nextInt();
		
		System.out.print("Introudeix un enter (columna): ");
		int m = in.nextInt();
		
		int matriu [][]=new int [n][m];
		
		int t = (int)(Math.random()*100);
		
		for(int i = 0; i<matriu.length; i++) {
			for(int j = 0; j<matriu.length; j++ ) {
				n = i *t;
				m = t;
				matriu[i][j] = n;
				matriu[i][j]= m;
				//matriu[i][j] = i+j; 
				
				System.out.print(matriu[i][j] + " ");
			}
			
			System.out.println();

			
		}
		
		
		
		
	}
}