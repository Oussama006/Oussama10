package navegadorweb;

class exceptionNavBar extends Menu{

	public exceptionNavBar(String mensage) {
		super();
	}
}
