package paquets4;

import java.util.*;

	class DissenyModular_2{
		static String faq() {
			
			Random aleatori = new Random();
			
			ArrayList<String> preguntas = new ArrayList<>();
			
			preguntas.add("Si creo una classe i no la poso en cap paquet en quin paquet estarà ? ");
			preguntas.add("Si tinc una classe en el default package la podrem veure des de un altre paquet ? Perquè? ");
			preguntas.add("Si tinc una classe sense cap qualificador public des d'on serà accessible (apunts Josep  Queralt apartat 34.21)? ");
			preguntas.add("Si tinc una classe amb el qualificador private en comptes de public des d'on serà accessible? ");
			preguntas.add("Si tinc una classe amb el qualificador package en comptes de public des d'on serà accessible? ");
			preguntas.add("Quin missatge d'error mostra l'eclipse quan intentes accedir a una classe sense qualificador d'un altre paquet? ");
			
			ArrayList<String> respostes = new ArrayList<>();
			
			respostes.add("Si no poses una classe en cap paquet, estarà en el default package.");
			respostes.add("No, una classe en el default package no es pot veure des d'un altre paquet perquè no es permet l'accés entre paquets diferents si no estan explícitament especificats.");
			respostes.add("Serà accessible només dins del mateix paquet.");
			respostes.add("No es pot declarar una classe com private en Java. Només els membres (atributs i mètodes) poden ser private.");
			respostes.add("Amb el qualificador package (per defecte, sense especificar public), només serà accessible des del mateix paquet.");
			respostes.add("Eclipse mostra un error del tipus: \"The type [ClassName] is not visible\".");
			
			String relacio = "";
			
			for(int i = 0; i < 3; i++) {
				int bucle = aleatori.nextInt(preguntas.size());
				relacio = relacio + preguntas.get(bucle);
				relacio = relacio + respostes.get(bucle);
			}
			return relacio;
		}
}